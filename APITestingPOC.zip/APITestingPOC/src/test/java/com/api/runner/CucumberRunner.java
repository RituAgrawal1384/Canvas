package com.api.runner;
import com.github.mkolisnyk.cucumber.runner.ExtendedCucumberOptions;
import com.github.mkolisnyk.cucumber.runner.ExtendedTestNGRunner;
import com.prudential.tap.config.Configvariable;
import com.prudential.tap.config.TapBeansLoad;
import com.prudential.tap.email.TapEmail;
import com.prudential.tap.filehandling.FileReaderUtil;
import com.prudential.tap.filehandling.ZipFolder;
import com.prudential.tap.reporting.TapReporting;
import com.prudential.tap.selenium.SeleniumBase;
import cucumber.api.CucumberOptions;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;
import org.apache.log4j.Logger;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.testng.annotations.*;

import java.util.TimeZone;

@ComponentScan(basePackages = {"com.pru.sales.portal", "com.prudential.tap", "com.pru.sales.api"})
@Configuration
@ExtendedCucumberOptions(
        jsonReport = "reports/cucumber/cucumber.json"
        , retryCount = 3
        , detailedReport = true
        , detailedAggregatedReport = true
        , overviewReport = true
        , jsonUsageReport = "reports/cucumber-usage.json"
        , usageReport = true
        , toPDF = true
        , outputFolder = "reports")
@CucumberOptions(
        monochrome = true,
        features = "classpath:features",
        glue = {"com/prudential/tap/tapsteps"},
        tags = {"@Login","~@ignore"},
        plugin = {"pretty",
                "html:reports/cucumber/cucumber-html",
                "json:reports/cucumber/cucumber.json",
                "usage:reports/cucumber-usage.json",
                "junit:reports/newrelic-report/cucumber-junit.xml"}
)

public class CucumberRunner extends ExtendedTestNGRunner {

    private static final Logger LOGGER = Logger.getLogger(CucumberRunner.class);

    private TestNGCucumberRunner testNGCucumberRunner;
    public static ConfigurableApplicationContext context;
    private Configvariable configvariable;
    private TapEmail tapEmail;



    @BeforeSuite(alwaysRun = true)
    public void setUpEnvironmentToTest() {
        // write if anything needs to be set up once before tests run. e.g. connection to database
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        TapBeansLoad.setConfigClass(CucumberRunner.class);
        TapBeansLoad.init();
        configvariable = (Configvariable) TapBeansLoad.getBean(Configvariable.class);

        tapEmail = (TapEmail) TapBeansLoad.getBean(TapEmail.class);
        LOGGER.info("Setting environment file....");
        //configvariable.setupEnvironmentProperties(System.getProperty("api.env"), System.getProperty("api.lbu"));

    }

    @BeforeClass()
    public void setUpClass() throws Exception {
        testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
    }

    @Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "features")
    public void feature(CucumberFeatureWrapper cucumberFeature) {
        testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
    }

    @DataProvider
    public Object[][] features() {
        return testNGCucumberRunner.provideFeatures();
    }

    @AfterClass(alwaysRun = true)
    public void tearDownClass() throws Exception {
        testNGCucumberRunner.finish();
    }

    @AfterSuite(alwaysRun = true)
    public void cleanUp() {
        // close if something enabled in @before suite. e.g. closing connection to DB
        LOGGER.info("Copying and generating reports....");
        String deviceFarmLogDir = System.getenv("DEVICEFARM_LOG_DIR");
        TapReporting.generateReportForJsonFiles(deviceFarmLogDir);
        LOGGER.info("Quiting driver if needed....");
        if (SeleniumBase.driver != null) {
            SeleniumBase.driver.quit();
        }
        FileReaderUtil.deleteFile("reports/Sales-portal-test-results.pdf");
        TapReporting.detailedReport("reports/cucumber/cucumber.json", "Sales-portal");

        if (System.getProperty("send.email") != null) {
            String filepath = "reports/cucumber/TestReports.zip";
            ZipFolder.zipFilesAndFolder("reports/cucumber/TestReports", filepath);
            tapEmail.sendEmail(filepath);
        }

    }

}

