$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/Login.feature");
formatter.feature({
  "line": 2,
  "name": "Testing apis Graphql",
  "description": "",
  "id": "testing-apis-graphql",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@tap_test"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "Testing login feature",
  "description": "",
  "id": "testing-apis-graphql;testing-login-feature",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 3,
      "name": "@Login"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "I generate random number and assign to variable \"RAND_NUM\"",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "I set system property \"system.proxy.apply\" to value \"false\"",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 7,
      "value": "#    Given I assign \"false\" to variable \"system.proxy.apply\""
    }
  ],
  "line": 8,
  "name": "I assign value to following variables",
  "rows": [
    {
      "cells": [
        "USER_NAME",
        "testAutomation-56789@mailinator.com"
      ],
      "line": 9
    },
    {
      "cells": [
        "PASSWORD",
        "Human123"
      ],
      "line": 10
    },
    {
      "cells": [
        "EMP_GIVEN_NAME",
        "Test_${RAND_NUM}"
      ],
      "line": 11
    },
    {
      "cells": [
        "EMP_FAMILY_NAME",
        "Emp_${RAND_NUM}"
      ],
      "line": 12
    },
    {
      "cells": [
        "EMP_EMAIL",
        "TestEmp_${RAND_NUM}@mailinator.com"
      ],
      "line": 13
    },
    {
      "cells": [
        "NODE",
        "login"
      ],
      "line": 14
    }
  ],
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "I create connection for api service",
  "keyword": "Given "
});
formatter.step({
  "line": 16,
  "name": "I set endpoint url as \"https://uat-api.eb.prudential.com.sg/graphql/hr-portal\"",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 17,
      "value": "#    And I set api header key \"fullstackdeployheader\" and value \"blue\""
    },
    {
      "line": 18,
      "value": "#    And I set api header key \"content-type\" and value \"application/json\""
    }
  ],
  "line": 19,
  "name": "I set api headers as below",
  "rows": [
    {
      "cells": [
        "fullstackdeployheader",
        "blue"
      ],
      "line": 20
    },
    {
      "cells": [
        "content-type",
        "application/json"
      ],
      "line": 21
    }
  ],
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "I set graphql request body from file \"/testdata/identityservice/login.graphql\"",
  "keyword": "And "
});
formatter.step({
  "line": 24,
  "name": "I send request \"post\" to api",
  "keyword": "And "
});
formatter.step({
  "line": 26,
  "name": "I verify response code is 200",
  "keyword": "Then "
});
formatter.step({
  "line": 27,
  "name": "I get response value for node \"data.login.token\" into variable \"LOGIN_TOKEN\"",
  "keyword": "And "
});
formatter.step({
  "line": 28,
  "name": "I set api headers as below",
  "rows": [
    {
      "cells": [
        "fullstackdeployheader",
        "blue"
      ],
      "line": 29
    },
    {
      "cells": [
        "content-type",
        "application/json"
      ],
      "line": 30
    },
    {
      "cells": [
        "Authorization",
        "Bearer ${LOGIN_TOKEN}"
      ],
      "line": 31
    }
  ],
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "I set graphql request body from file \"/testdata/quotations/addEmployeeToPolicy.graphql\"",
  "keyword": "And "
});
formatter.step({
  "line": 33,
  "name": "I send request \"post\" to api",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "I verify response code is 200",
  "keyword": "Then "
});
formatter.step({
  "line": 35,
  "name": "I get response value for node \"data.addEmployee.id\" into variable \"EMP_ID\"",
  "keyword": "And "
});
formatter.step({
  "line": 36,
  "name": "I verify response value for node \"data.addEmployee.givenName\" is \"${EMP_GIVEN_NAME}\"",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "RAND_NUM",
      "offset": 49
    }
  ],
  "location": "ConfigvariableSteps.generateRandomNumberAndAssignToVariable(String)"
});
formatter.result({
  "duration": 123793367,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "system.proxy.apply",
      "offset": 23
    },
    {
      "val": "false",
      "offset": 53
    }
  ],
  "location": "ConfigvariableSteps.setSystemProperty(String,String)"
});
formatter.result({
  "duration": 80316,
  "status": "passed"
});
formatter.match({
  "location": "ConfigvariableSteps.assignValueToVariables(DataTable)"
});
formatter.result({
  "duration": 750904,
  "status": "passed"
});
formatter.match({
  "location": "APISteps.createConnection()"
});
formatter.result({
  "duration": 147146388,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "https://uat-api.eb.prudential.com.sg/graphql/hr-portal",
      "offset": 23
    }
  ],
  "location": "APISteps.setEndpointURL(String)"
});
formatter.result({
  "duration": 274556,
  "status": "passed"
});
formatter.match({
  "location": "APISteps.setApiHeaders(DataTable)"
});
formatter.result({
  "duration": 268669,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "/testdata/identityservice/login.graphql",
      "offset": 38
    }
  ],
  "location": "APISteps.setGraphQlRequestBody(String)"
});
formatter.result({
  "duration": 266102388,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "post",
      "offset": 16
    }
  ],
  "location": "APISteps.sendMultipartPostRequest(String)"
});
formatter.result({
  "duration": 399349381,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "200",
      "offset": 26
    }
  ],
  "location": "APISteps.verifyStatusCode(int)"
});
formatter.result({
  "duration": 1622589,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "data.login.token",
      "offset": 31
    },
    {
      "val": "LOGIN_TOKEN",
      "offset": 64
    }
  ],
  "location": "APISteps.getResponseNodeData(String,String)"
});
formatter.result({
  "duration": 32650558,
  "status": "passed"
});
formatter.match({
  "location": "APISteps.setApiHeaders(DataTable)"
});
formatter.result({
  "duration": 236786,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "/testdata/quotations/addEmployeeToPolicy.graphql",
      "offset": 38
    }
  ],
  "location": "APISteps.setGraphQlRequestBody(String)"
});
formatter.result({
  "duration": 998270,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "post",
      "offset": 16
    }
  ],
  "location": "APISteps.sendMultipartPostRequest(String)"
});
formatter.result({
  "duration": 1775158251,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "200",
      "offset": 26
    }
  ],
  "location": "APISteps.verifyStatusCode(int)"
});
formatter.result({
  "duration": 86085,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "data.addEmployee.id",
      "offset": 31
    },
    {
      "val": "EMP_ID",
      "offset": 67
    }
  ],
  "location": "APISteps.getResponseNodeData(String,String)"
});
formatter.result({
  "duration": 719450,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "data.addEmployee.givenName",
      "offset": 34
    },
    {
      "val": "${EMP_GIVEN_NAME}",
      "offset": 66
    }
  ],
  "location": "APISteps.verifyResponseData(String,String)"
});
formatter.result({
  "duration": 1121579,
  "status": "passed"
});
});