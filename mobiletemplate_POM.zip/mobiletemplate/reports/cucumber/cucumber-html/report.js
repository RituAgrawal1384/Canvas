$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/TAPUsage.feature");
formatter.feature({
  "line": 2,
  "name": "Login to mobile app",
  "description": "",
  "id": "login-to-mobile-app",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@test_tap"
    }
  ]
});
formatter.before({
  "duration": 376637,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "comments": [
    {
      "line": 5,
      "value": "#    Given I load property file \"/locators/th/en_android.csv\" into global property map"
    }
  ],
  "line": 6,
  "name": "I load environment property file \"uat\" into global property map for lbu \"th\"",
  "keyword": "And "
});
formatter.step({
  "line": 7,
  "name": "I load csv file \"/locators/th/en_android.csv\" with separator \"\u003d\" into global property map",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "uat",
      "offset": 34
    },
    {
      "val": "th",
      "offset": 73
    }
  ],
  "location": "FileHandlingSteps.loadEnvironmentPropertyFile(String,String)"
});
formatter.result({
  "duration": 104847267,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "/locators/th/en_android.csv",
      "offset": 17
    },
    {
      "val": "\u003d",
      "offset": 62
    }
  ],
  "location": "FileHandlingSteps.loadCsvFile(String,String)"
});
formatter.result({
  "duration": 10773963,
  "status": "passed"
});
formatter.scenario({
  "comments": [
    {
      "line": 9,
      "value": "#  Scenario: Login to pulse SDK using TAP step without glue code"
    },
    {
      "line": 10,
      "value": "#    Given I get device platform into variable \"DEVICE_PLATFORM\""
    },
    {
      "line": 11,
      "value": "#    When I launch \"${DEVICE_PLATFORM}\" mobile application"
    },
    {
      "line": 12,
      "value": "#    And I enter text \"${login.id.global}\" on element \"${text.field.email}\""
    },
    {
      "line": 13,
      "value": "#    And I clear text on element \"${text.field.email}\""
    },
    {
      "line": 14,
      "value": "#    And I enter text \"${login.id.global}\" on element \"${text.field.email}\""
    },
    {
      "line": 15,
      "value": "#    And I swipe mobile down by duration \"6000\""
    },
    {
      "line": 16,
      "value": "#    And I swipe mobile down till element displayed \"${button.submit}\""
    },
    {
      "line": 17,
      "value": "#    And I click on element \"${button.submit}\""
    },
    {
      "line": 18,
      "value": "#    Then I verify element \"${text.group.insurance}\" is displayed"
    },
    {
      "line": 19,
      "value": "#    And I click on element \"${tile.make.claim}\""
    },
    {
      "line": 20,
      "value": "#    And I sleep for 5 sec"
    },
    {
      "line": 21,
      "value": "#    And I swipe mobile down till element displayed \"${button.permanent.dissability}\""
    },
    {
      "line": 22,
      "value": "#    And I click on element \"${button.permanent.dissability}\""
    },
    {
      "line": 23,
      "value": "#    And I click on element \"${button.arrow}\""
    },
    {
      "line": 24,
      "value": "#    And I sleep for 5 sec"
    },
    {
      "line": 25,
      "value": "#    And I swipe mobile down by duration \"6000\""
    }
  ],
  "line": 27,
  "name": "Example of how to write custom gluecode",
  "description": "",
  "id": "login-to-mobile-app;example-of-how-to-write-custom-gluecode",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 28,
  "name": "I get device platform into variable \"DEVICE_PLATFORM\"",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "I launch \"${DEVICE_PLATFORM}\" mobile application",
  "keyword": "When "
});
formatter.step({
  "line": 30,
  "name": "I login to employee sdk using email \"${login.id.global}\"",
  "keyword": "And "
});
formatter.match({
  "arguments": [
    {
      "val": "DEVICE_PLATFORM",
      "offset": 37
    }
  ],
  "location": "UISteps.getDevicePlatform(String)"
});
formatter.result({
  "duration": 331661,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "${DEVICE_PLATFORM}",
      "offset": 10
    }
  ],
  "location": "UISteps.launchMobileApplication(String)"
});
formatter.result({
  "duration": 8641584190,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "${login.id.global}",
      "offset": 37
    }
  ],
  "location": "LoginStep.loginToPulseApp(String)"
});
formatter.result({
  "duration": 25884248540,
  "status": "passed"
});
formatter.after({
  "duration": 175218,
  "status": "passed"
});
});