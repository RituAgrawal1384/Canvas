package com.mobile.template.stepdef;


import com.mobile.template.screen.LoginPage;
import com.prudential.tap.config.TapBeansLoad;
import cucumber.api.java.en.Given;
import org.apache.log4j.Logger;


public class LoginStep {
    private static final Logger logger = Logger.getLogger(LoginStep.class);

    private LoginPage loginPage = (LoginPage) TapBeansLoad.getBean(LoginPage.class);

    @Given("^I login to employee sdk using email \"([^\"]*)\"$")
    public void loginToPulseApp(String emailId) {
        loginPage.loginToPulse(emailId);
    }

}