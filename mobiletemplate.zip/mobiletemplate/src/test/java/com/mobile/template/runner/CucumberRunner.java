package com.mobile.template.runner;

import com.github.mkolisnyk.cucumber.runner.ExtendedTestNGRunner;
import com.mobile.template.utils.HelperMethods;
import com.prudential.tap.config.Configvariable;
import com.prudential.tap.config.TapBeansLoad;
import com.prudential.tap.filehandling.FileReaderUtil;
import com.prudential.tap.reporting.TapReporting;
import com.prudential.tap.selenium.SeleniumBase;
import cucumber.api.CucumberOptions;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;
import org.apache.log4j.Logger;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.util.TimeZone;

@ComponentScan(basePackages = {"com.mobile.template", "com.prudential.tap"})
@Configuration
@CucumberOptions(
        monochrome = true,
        features = "classpath:features",
        glue = {"com/mobile/template/stepdef","com/prudential/tap/tapsteps"},
        tags = {"@test_tap", "~@ignore"},

        plugin = {"pretty",
                "html:reports/cucumber/cucumber-html",
                "json:reports/cucumber/cucumber.json",
                "usage:reports/cucumber-usage.json",
                "junit:reports/newrelic-report/cucumber-junit.xml"}
)

public class CucumberRunner extends ExtendedTestNGRunner {

    private static final Logger LOGGER = Logger.getLogger(CucumberRunner.class);

    private TestNGCucumberRunner testNGCucumberRunner;
    private Configvariable configvariable;
    private SeleniumBase seleniumBase;
    private HelperMethods helperMethods;

    @BeforeSuite(alwaysRun = true)
    public void setUpEnvironmentToTest() {
        // write if anything needs to be set up once before tests run. e.g. connection to database
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
        TapBeansLoad.setConfigClass(CucumberRunner.class);
        TapBeansLoad.init();
        configvariable = (Configvariable) TapBeansLoad.getBean(Configvariable.class);
        seleniumBase = (SeleniumBase) TapBeansLoad.getBean(SeleniumBase.class);
//        helperMethods = (HelperMethods) TapBeansLoad.getBean(HelperMethods.class);
//        LOGGER.info("Setting environment file....");
//        configvariable.setupEnvironmentProperties(System.getProperty("app.env"), System.getProperty("app.lbu"));
//        LOGGER.info("Setting localization file....");
//        helperMethods.loadLocalizationFile(System.getProperty("app.lbu"), System.getProperty("app.language"), System.getenv("DEVICEFARM_DEVICE_PLATFORM_NAME"));
//        seleniumBase.initializeSeleniumFramework();
    }

    @BeforeClass()
    public void setUpClass() throws Exception {
        testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
    }

    @Test(groups = "cucumber", description = "Runs Cucumber Feature", dataProvider = "features")
    public void feature(CucumberFeatureWrapper cucumberFeature) {
        testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
    }

    @DataProvider
    public Object[][] features() {
        return testNGCucumberRunner.provideFeatures();
    }

    @AfterClass(alwaysRun = true)
    public void tearDownClass() throws Exception {
        testNGCucumberRunner.finish();
    }

    @AfterSuite(alwaysRun = true)
    public void cleanUp() {
        // close if something enabled in @before suite. e.g. closing connection to DB
        LOGGER.info("Copying and generating reports....");
        String deviceFarmLogDir = System.getenv("DEVICEFARM_LOG_DIR");
        TapReporting.generateReportForJsonFiles(deviceFarmLogDir);
        // so it might get exception
        LOGGER.info("Quiting driver if needed....");
        if (SeleniumBase.driver != null) {
            SeleniumBase.driver.quit();
        }

        FileReaderUtil.deleteFile("reports/Employee-portal-test-results.pdf");
        TapReporting.detailedReport("reports/cucumber/cucumber.json", "Employee-portal");

    }

}